create view ii  as  select *from InBill;
go

