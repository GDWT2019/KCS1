create view vi  as  select * from InBill;
go

